const Joi = require('joi');
const { XMLParser } = require('fast-xml-parser');

const paymentSchema = Joi.object({
  userId: Joi.string().optional(),
  companyName: Joi.string().min(2).required(),
  clientId: Joi.string().allow('').optional(),
  contactPerson: Joi.string().allow('').optional(),
  emailAddress: Joi.string().email().allow('').optional(),
  debitAccountNumber: Joi.string().pattern(/^[0-9]{8,20}$/).required(),
  accountName: Joi.string().min(2).required(),
  branchCode: Joi.string().min(2).max(12).required(),
  currency: Joi.string().length(3).uppercase().required(),
  beneficiaryName: Joi.string().min(2).required(),
  beneficiaryAccountNumber: Joi.string().pattern(/^[0-9]{8,20}$/).required(),
  beneficiaryBankCode: Joi.string().min(2).max(12).required(),
  beneficiaryBranchCode: Joi.string().allow('').optional(),
  paymentType: Joi.string().valid('TRF', 'EFT', 'RTGS', 'ACH').required(),
  amount: Joi.number().positive().required(),
  paymentReference: Joi.string().min(3).max(35).required(),
  narration: Joi.string().max(140).allow('').optional(),
  valueDate: Joi.date().iso().required()
});

function validatePaymentPayload(payload) {
  return paymentSchema.validate(payload, { abortEarly: false, stripUnknown: true });
}

function validateXmlSyntax(xml) {
  try {
    const parser = new XMLParser({ ignoreAttributes: false });
    parser.parse(xml);
    return { valid: true, errors: [] };
  } catch (error) {
    return { valid: false, errors: [error.message] };
  }
}

module.exports = { validatePaymentPayload, validateXmlSyntax };
