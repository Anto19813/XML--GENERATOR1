require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const xmlRoutes = require('./routes/xmlRoutes');
const auditRoutes = require('./routes/auditRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '2mb' }));

app.get('/health', (_req, res) => {
  res.json({ status: 'UP', service: 'Stanbic Bank H2H XML AutoGen Portal API' });
});

app.use('/api/xml', xmlRoutes);
app.use('/api/audit', auditRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error'
  });
});

app.listen(PORT, () => {
  console.log(`API running on port ${PORT}`);
});
