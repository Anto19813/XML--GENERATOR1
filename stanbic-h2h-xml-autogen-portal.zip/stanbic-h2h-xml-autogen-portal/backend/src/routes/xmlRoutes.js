const express = require('express');
const router = express.Router();
const { generatePaymentXml } = require('../services/xmlGenerator');
const { validatePaymentPayload, validateXmlSyntax } = require('../validators/xmlValidator');
const { saveAudit } = require('../services/auditService');

router.post('/generate', async (req, res, next) => {
  try {
    const { error, value } = validatePaymentPayload(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: error.details.map((d) => d.message)
      });
    }

    const xml = generatePaymentXml(value);
    const syntaxResult = validateXmlSyntax(xml);

    await saveAudit({
      userId: value.userId || 'demo-user',
      clientName: value.companyName,
      action: 'GENERATE_XML',
      fileName: `${value.companyName.replace(/\s+/g, '_')}_PAIN001_${new Date().toISOString().slice(0, 10)}.xml`,
      status: syntaxResult.valid ? 'VALIDATED' : 'FAILED'
    });

    res.json({
      success: syntaxResult.valid,
      message: syntaxResult.valid ? 'XML generated and validated successfully' : 'XML generated but syntax validation failed',
      xml,
      validation: syntaxResult
    });
  } catch (err) {
    next(err);
  }
});

router.post('/validate', (req, res) => {
  const { xml } = req.body;
  if (!xml) {
    return res.status(400).json({ success: false, message: 'XML content is required' });
  }
  const result = validateXmlSyntax(xml);
  res.json({ success: result.valid, validation: result });
});

router.post('/download', (req, res) => {
  const { xml, fileName } = req.body;
  if (!xml) {
    return res.status(400).json({ success: false, message: 'XML content is required' });
  }

  const safeFileName = fileName || `H2H_PAYMENT_${Date.now()}.xml`;
  res.setHeader('Content-Type', 'application/xml');
  res.setHeader('Content-Disposition', `attachment; filename="${safeFileName}"`);
  res.send(xml);
});

module.exports = router;
