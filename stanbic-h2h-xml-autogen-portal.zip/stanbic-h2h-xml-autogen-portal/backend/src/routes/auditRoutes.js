const express = require('express');
const router = express.Router();
const { listAuditLogs } = require('../services/auditService');

router.get('/', async (_req, res, next) => {
  try {
    const logs = await listAuditLogs();
    res.json({ success: true, logs });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
