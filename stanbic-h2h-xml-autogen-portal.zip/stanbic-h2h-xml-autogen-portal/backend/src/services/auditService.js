const auditLogs = [];

async function saveAudit(log) {
  const record = {
    id: auditLogs.length + 1,
    ...log,
    createdAt: new Date().toISOString()
  };
  auditLogs.unshift(record);
  return record;
}

async function listAuditLogs() {
  return auditLogs;
}

module.exports = { saveAudit, listAuditLogs };
