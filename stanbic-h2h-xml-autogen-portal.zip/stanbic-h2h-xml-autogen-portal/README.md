# Stanbic Bank H2H XML AutoGen Portal

A web-based application for generating, validating, previewing and exporting H2H XML files.

## Technology Stack

- Frontend: React.js with Vite
- Backend: Node.js / Express
- Database: PostgreSQL or MySQL ready structure
- Validation: XML syntax validation and business-rule validation, ready for XSD integration
- Export: XML download function
- Hosting: Cloud server or internal bank server

## Project Structure

```text
stanbic-h2h-xml-autogen-portal/
├── backend/
│   ├── src/
│   │   ├── db/schema.sql
│   │   ├── routes/xmlRoutes.js
│   │   ├── routes/auditRoutes.js
│   │   ├── services/xmlGenerator.js
│   │   ├── services/auditService.js
│   │   ├── validators/xmlValidator.js
│   │   └── server.js
│   └── package.json
└── frontend/
    ├── src/
    │   ├── App.jsx
    │   ├── styles.css
    │   └── services/api.js
    └── package.json
```

## Run Backend

```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Backend runs on:

```text
http://localhost:5000
```

## Run Frontend

```bash
cd frontend
npm install
npm start
```

Frontend runs on:

```text
http://localhost:5173
```

## API Endpoints

### Generate XML

```http
POST /api/xml/generate
```

### Validate XML

```http
POST /api/xml/validate
```

### Download XML

```http
POST /api/xml/download
```

### Audit Logs

```http
GET /api/audit
```

## Current Capabilities

- Guided transaction capture form
- Automatic XML generation
- XML syntax validation
- Business rule validation
- XML preview
- XML download/export
- Audit logging structure
- Database schema starter file

## Recommended Next Enhancements

1. Add official Stanbic H2H XSD files for full schema validation.
2. Replace in-memory audit logging with PostgreSQL persistence.
3. Add Maker/Checker workflow.
4. Add login, JWT authentication and role-based access.
5. Add bulk upload from Excel/CSV to generate multi-transaction XML files.
6. Add admin module for template and validation rule setup.
