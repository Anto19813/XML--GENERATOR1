import { useState } from 'react';
import { generateXml, downloadXml } from './services/api';

const initialForm = {
  companyName: '',
  clientId: '',
  contactPerson: '',
  emailAddress: '',
  debitAccountNumber: '',
  accountName: '',
  branchCode: '',
  currency: 'UGX',
  beneficiaryName: '',
  beneficiaryAccountNumber: '',
  beneficiaryBankCode: '',
  beneficiaryBranchCode: '',
  paymentType: 'TRF',
  amount: '',
  paymentReference: '',
  narration: '',
  valueDate: new Date().toISOString().slice(0, 10)
};

function App() {
  const [form, setForm] = useState(initialForm);
  const [xml, setXml] = useState('');
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleGenerate = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    try {
      const data = await generateXml({ ...form, amount: Number(form.amount) });
      setXml(data.xml || '');
      setStatus({ type: data.success ? 'success' : 'error', message: data.message, errors: data.errors || data.validation?.errors || [] });
    } catch (err) {
      setStatus({
        type: 'error',
        message: err.response?.data?.message || 'Unable to generate XML',
        errors: err.response?.data?.errors || []
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    const safeClient = form.companyName.replace(/\s+/g, '_') || 'CLIENT';
    const fileName = `${safeClient}_${form.paymentType}_${new Date().toISOString().slice(0, 10)}.xml`;
    downloadXml(xml, fileName);
  };

  return (
    <main>
      <header className="hero">
        <div>
          <p className="eyebrow">Stanbic Bank</p>
          <h1>H2H XML AutoGen Portal</h1>
          <p>Generate, validate, preview and export H2H XML files in under 2 minutes.</p>
        </div>
        <div className="badge">Pain.001 Ready</div>
      </header>

      <section className="layout">
        <form className="card form" onSubmit={handleGenerate}>
          <h2>Transaction Capture</h2>
          <div className="grid">
            <Input label="Company Name" name="companyName" value={form.companyName} onChange={handleChange} required />
            <Input label="Client ID" name="clientId" value={form.clientId} onChange={handleChange} />
            <Input label="Contact Person" name="contactPerson" value={form.contactPerson} onChange={handleChange} />
            <Input label="Email Address" name="emailAddress" value={form.emailAddress} onChange={handleChange} />
            <Input label="Debit Account Number" name="debitAccountNumber" value={form.debitAccountNumber} onChange={handleChange} required />
            <Input label="Account Name" name="accountName" value={form.accountName} onChange={handleChange} required />
            <Input label="Branch Code" name="branchCode" value={form.branchCode} onChange={handleChange} required />
            <Input label="Currency" name="currency" value={form.currency} onChange={handleChange} required />
            <Input label="Beneficiary Name" name="beneficiaryName" value={form.beneficiaryName} onChange={handleChange} required />
            <Input label="Beneficiary Account Number" name="beneficiaryAccountNumber" value={form.beneficiaryAccountNumber} onChange={handleChange} required />
            <Input label="Beneficiary Bank Code" name="beneficiaryBankCode" value={form.beneficiaryBankCode} onChange={handleChange} required />
            <Input label="Beneficiary Branch Code" name="beneficiaryBranchCode" value={form.beneficiaryBranchCode} onChange={handleChange} />
            <label>
              Payment Type
              <select name="paymentType" value={form.paymentType} onChange={handleChange}>
                <option value="TRF">TRF</option>
                <option value="EFT">EFT</option>
                <option value="RTGS">RTGS</option>
                <option value="ACH">ACH</option>
              </select>
            </label>
            <Input label="Amount" name="amount" type="number" value={form.amount} onChange={handleChange} required />
            <Input label="Payment Reference" name="paymentReference" value={form.paymentReference} onChange={handleChange} required />
            <Input label="Value Date" name="valueDate" type="date" value={form.valueDate} onChange={handleChange} required />
          </div>
          <label>
            Narration
            <textarea name="narration" value={form.narration} onChange={handleChange} rows="3" />
          </label>
          <button type="submit" disabled={loading}>{loading ? 'Generating...' : 'Generate & Validate XML'}</button>
        </form>

        <section className="card preview">
          <h2>XML Preview</h2>
          {status && (
            <div className={`alert ${status.type}`}>
              <strong>{status.message}</strong>
              {status.errors?.length > 0 && <ul>{status.errors.map((err) => <li key={err}>{err}</li>)}</ul>}
            </div>
          )}
          <pre>{xml || 'XML output will appear here after generation.'}</pre>
          <button onClick={handleDownload} disabled={!xml || status?.type !== 'success'}>Download XML</button>
        </section>
      </section>
    </main>
  );
}

function Input({ label, ...props }) {
  return (
    <label>
      {label}
      <input {...props} />
    </label>
  );
}

export default App;
