import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
});

export async function generateXml(payload) {
  const response = await api.post('/xml/generate', payload);
  return response.data;
}

export async function downloadXml(xml, fileName) {
  const response = await api.post('/xml/download', { xml, fileName }, { responseType: 'blob' });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/xml' }));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  link.remove();
}
